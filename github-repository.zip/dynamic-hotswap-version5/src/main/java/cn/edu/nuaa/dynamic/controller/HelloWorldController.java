package cn.edu.nuaa.dynamic.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import cn.edu.nuaa.demo.Hello;
import cn.edu.nuaa.dynamic.annotation.EnableRefresh;
import cn.edu.nuaa.dynamic.annotation.Refreshable;

@RestController
@EnableRefresh
public class HelloWorldController {
	
	@Autowired
	@Refreshable
	private  Hello hello;
	
	@RequestMapping(path="/hello", method=RequestMethod.GET)
	public String sayHello(@RequestParam String msg) throws IOException {
		return hello.sayHello(msg);
	}
	
}
