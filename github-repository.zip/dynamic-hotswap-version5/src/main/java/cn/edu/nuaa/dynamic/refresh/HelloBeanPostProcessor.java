package cn.edu.nuaa.dynamic.refresh;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.net.MalformedURLException;
import java.net.URL;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.stereotype.Component;

import com.alipay.jarslink.api.ModuleConfig;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;

import cn.edu.nuaa.demo.Hello;
import cn.edu.nuaa.dynamic.annotation.EnableRefresh;
import cn.edu.nuaa.dynamic.annotation.Refreshable;
import cn.edu.nuaa.dynamic.api.ModuleLoader;

@Component
public class HelloBeanPostProcessor implements BeanPostProcessor {
	
	private static final String JARPATH = "file:D:/swap/common-jarslink-0.0.1-SNAPSHOT.jar";
	
//	private ApplicationContext applicationContext;
	
	@Autowired
	private ModuleLoader moduleLoader;
	
	@Autowired
	private ModuleConfig moduleConfig;
		
	public HelloBeanPostProcessor() {
	}
	
	
	@Override
	public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
		Class<? extends Object> clazz = bean.getClass();
		EnableRefresh enableRefresh = clazz.getDeclaredAnnotation(EnableRefresh.class);
		if(enableRefresh != null) {
			Field[] declaredFields = clazz.getDeclaredFields();
			for(Field field: declaredFields) {
				if(field.getAnnotation(Refreshable.class) != null) {
					
				}
			}
		}
		
		try {
			buildModuleConfig();
			System.err.println("load start................");
			ConfigurableApplicationContext context = moduleLoader.load(moduleConfig);
			System.err.println("load end.............");
			
			Hello hello = context.getBean(Hello.class);
			System.out.println(hello.sayHello("HH"));
			
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		return bean;
	}

	@Override
	public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
		return bean;
	}
	
/*	@Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }
*/	
	private void buildModuleConfig() throws MalformedURLException {
		URL moduleURL = new URL(JARPATH);
		moduleConfig.setName("demo");
		moduleConfig.setEnabled(true);
		moduleConfig.setVersion("1.1.1");
		moduleConfig.setModuleUrl(ImmutableList.of(moduleURL));
		moduleConfig.addScanPackage("cn.edu.nuaa.demo");
		moduleConfig.setOverridePackages(ImmutableList.of("cn.edu.nuaa.demo"));
		moduleConfig.setProperties(ImmutableMap.of("path", "127.0.0.1"));
	}
	
}
