package cn.edu.nuaa.demo;

public class HelloWorld implements Hello {

	@Override
	public String sayHello(String msg) {
		return "Hello "+msg+" version 1";
	}

}
