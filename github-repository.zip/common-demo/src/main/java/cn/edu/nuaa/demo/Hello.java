package cn.edu.nuaa.demo;

public interface Hello {
	
	public String sayHello(String msg);
}
